export const feedback = [
  {
    message: 'Lovely app',
    id: '8a400816-9ccf-40c3-9d63-33cb3ca01217',
    feedbackType: 'FEEDBACK',
    name: 'Mahmoud',
    email: 'mahmoud@prisma.io',
  },
  {
    message: 'Add dark mode',
    id: 'bdac3e8f-4196-40de-b79b-d8a24525a277',
    feedbackType: 'IDEA',
    name: 'Dan',
    email: 'dan@prisma.io',
  },
  {
    message: 'layout is broken on mobile',
    id: '35b63612-06f5-4665-9719-b56ed6271478',
    feedbackType: 'ISSUE',
    name: 'Alex',
    email: 'alex@prisma.io',
  },
];
