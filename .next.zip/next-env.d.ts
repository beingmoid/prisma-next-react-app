/// <reference types="next" />
/// <reference types="next/types/global" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/basic-features/typescript for more information.
DATABASE_URL="prisma://aws-us-east-1.prisma-data.com/?api_key=m9XVi_z7IGWiisvI-FGTIa4EgRzhOStd4efz33Q-vTiC5Z5Uxh-3GptBY1-PGk11"