"use strict";
(() => {
var exports = {};
exports.id = "pages/api/create";
exports.ids = ["pages/api/create"];
exports.modules = {

/***/ "./lib/prisma.ts":
/*!***********************!*\
  !*** ./lib/prisma.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "prisma": () => (/* binding */ prisma)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ "@prisma/client");
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prisma = global.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (true) global.prisma = prisma;

/***/ }),

/***/ "./pages/api/create.ts":
/*!*****************************!*\
  !*** ./pages/api/create.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lib/prisma */ "./lib/prisma.ts");

async function handler(req, res) {
  const {
    feedbackType,
    message,
    email,
    name
  } = req.body;

  try {
    const feedback = await lib_prisma__WEBPACK_IMPORTED_MODULE_0__.prisma.feedback.create({
      data: {
        message,
        feedbackType,
        name,
        email
      }
    });
    res.status(200).json(feedback);
  } catch (error) {
    res.status(400).json({
      message: `Something went wrong :/ ${error}`
    });
  }
}

/***/ }),

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/create.ts"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvYXBpL2NyZWF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFNTyxNQUFNQyxNQUFNLEdBQUdDLE1BQU0sQ0FBQ0QsTUFBUCxJQUFpQixJQUFJRCx3REFBSixFQUFoQztBQUVQLElBQUksTUFBdUNFLE1BQU0sQ0FBQ0QsTUFBUCxHQUFnQkEsTUFBaEI7Ozs7Ozs7Ozs7Ozs7OztBQ1IzQztBQUVlLGVBQWVFLE9BQWYsQ0FBdUJDLEdBQXZCLEVBQTRCQyxHQUE1QixFQUFpQztBQUM5QyxRQUFNO0FBQUVDLElBQUFBLFlBQUY7QUFBZ0JDLElBQUFBLE9BQWhCO0FBQXlCQyxJQUFBQSxLQUF6QjtBQUFnQ0MsSUFBQUE7QUFBaEMsTUFBeUNMLEdBQUcsQ0FBQ00sSUFBbkQ7O0FBRUEsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNViw4REFBQSxDQUF1QjtBQUM1Q1ksTUFBQUEsSUFBSSxFQUFFO0FBQ0pOLFFBQUFBLE9BREk7QUFFSkQsUUFBQUEsWUFGSTtBQUdKRyxRQUFBQSxJQUhJO0FBSUpELFFBQUFBO0FBSkk7QUFEc0MsS0FBdkIsQ0FBdkI7QUFRQUgsSUFBQUEsR0FBRyxDQUFDUyxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUJKLFFBQXJCO0FBQ0QsR0FWRCxDQVVFLE9BQU9LLEtBQVAsRUFBYztBQUNkWCxJQUFBQSxHQUFHLENBQUNTLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUNuQlIsTUFBQUEsT0FBTyxFQUFHLDJCQUEwQlMsS0FBTTtBQUR2QixLQUFyQjtBQUdEO0FBQ0Y7Ozs7Ozs7Ozs7QUNwQkQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mZWVkYmFjay1hcHAvLi9saWIvcHJpc21hLnRzIiwid2VicGFjazovL2ZlZWRiYWNrLWFwcC8uL3BhZ2VzL2FwaS9jcmVhdGUudHMiLCJ3ZWJwYWNrOi8vZmVlZGJhY2stYXBwL2V4dGVybmFsIFwiQHByaXNtYS9jbGllbnRcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tICdAcHJpc21hL2NsaWVudCc7XHJcblxyXG5kZWNsYXJlIGdsb2JhbCB7XHJcbiAgdmFyIHByaXNtYTogUHJpc21hQ2xpZW50IHwgdW5kZWZpbmVkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgcHJpc21hID0gZ2xvYmFsLnByaXNtYSB8fCBuZXcgUHJpc21hQ2xpZW50KCk7XHJcblxyXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgZ2xvYmFsLnByaXNtYSA9IHByaXNtYTtcclxuIiwiaW1wb3J0IHsgcHJpc21hIH0gZnJvbSAnbGliL3ByaXNtYSc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgY29uc3QgeyBmZWVkYmFja1R5cGUsIG1lc3NhZ2UsIGVtYWlsLCBuYW1lIH0gPSByZXEuYm9keTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGZlZWRiYWNrID0gYXdhaXQgcHJpc21hLmZlZWRiYWNrLmNyZWF0ZSh7XHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBtZXNzYWdlLFxyXG4gICAgICAgIGZlZWRiYWNrVHlwZSxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICByZXMuc3RhdHVzKDIwMCkuanNvbihmZWVkYmFjayk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcclxuICAgICAgbWVzc2FnZTogYFNvbWV0aGluZyB3ZW50IHdyb25nIDovICR7ZXJyb3J9YCxcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAcHJpc21hL2NsaWVudFwiKTsiXSwibmFtZXMiOlsiUHJpc21hQ2xpZW50IiwicHJpc21hIiwiZ2xvYmFsIiwiaGFuZGxlciIsInJlcSIsInJlcyIsImZlZWRiYWNrVHlwZSIsIm1lc3NhZ2UiLCJlbWFpbCIsIm5hbWUiLCJib2R5IiwiZmVlZGJhY2siLCJjcmVhdGUiLCJkYXRhIiwic3RhdHVzIiwianNvbiIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==